export interface User {
  id: string;
  email: string;
  name: string;
  birthday?: string;
  nationality?: string;
  profileImage?: string;
  createdAt: string;
}

export interface Photo {
  id: string;
  userId: string;
  url: string;
  filename: string;
  uploadedAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}